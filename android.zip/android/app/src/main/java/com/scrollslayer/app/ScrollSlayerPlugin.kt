package com.scrollslayer.app

import android.content.Intent
import android.provider.Settings
import com.getcapacitor.JSObject
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin

@CapacitorPlugin(name = "ScrollSlayerNative")
class ScrollSlayerPlugin : Plugin() {
    @PluginMethod
    fun syncSettings(call: PluginCall) {
        val limit = call.getInt("limit") ?: 0
        if (limit < 0 || limit > 10000) {
            call.reject("Daily limit must be between 1 and 10000, or 0 before setup.")
            return
        }

        ProtectionStore.configure(
            context,
            limit,
            call.getInt("pendingLimit") ?: 0,
            call.getLong("pendingAt") ?: 0L,
            call.getBoolean("instagram", true) ?: true,
            call.getBoolean("youtube", true) ?: true
        )
        call.resolve()
    }

    @PluginMethod
    fun getWeeklyStats(call: PluginCall) {
        val snapshot = ProtectionStore.snapshot(context)
        val result = JSObject()
            .put("today", snapshot.today)
            .put("limit", snapshot.limit)
            .put("instagramToday", snapshot.instagramToday)
            .put("youtubeToday", snapshot.youtubeToday)
            .put("weeklyTotal", snapshot.weeklyTotal)
            .put("instagramWeekly", snapshot.instagramWeekly)
            .put("youtubeWeekly", snapshot.youtubeWeekly)
            .put("accessibilityEnabled", isAccessibilityServiceEnabled())
        call.resolve(result)
    }

    @PluginMethod
    fun openAccessibilitySettings(call: PluginCall) {
        activity.runOnUiThread {
            activity.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            call.resolve()
        }
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val enabledServices = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabledServices.split(':').any {
            it.equals(
                "${context.packageName}/${ShortFeedAccessibilityService::class.java.name}",
                ignoreCase = true
            )
        }
    }
}
