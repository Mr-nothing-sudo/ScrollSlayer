package com.scrollslayer.app

import com.getcapacitor.BridgeActivity

class MainActivity : BridgeActivity() {
    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        registerPlugin(ScrollSlayerPlugin::class.java)
        super.onCreate(savedInstanceState)
    }
}
