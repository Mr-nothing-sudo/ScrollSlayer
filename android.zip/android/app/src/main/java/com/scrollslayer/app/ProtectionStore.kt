package com.scrollslayer.app

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

internal data class ProtectionSnapshot(
    val limit: Int,
    val today: Int,
    val instagramToday: Int,
    val youtubeToday: Int,
    val weeklyTotal: Int,
    val instagramWeekly: Int,
    val youtubeWeekly: Int
)

internal object ProtectionStore {
    private const val PREFS = "scrollslayer_protection"
    private const val KEY_DATE = "counter_date"
    private const val KEY_LIMIT = "daily_limit"
    private const val KEY_INSTAGRAM_ENABLED = "instagram_enabled"
    private const val KEY_YOUTUBE_ENABLED = "youtube_enabled"
    private const val KEY_INSTAGRAM = "instagram_today"
    private const val KEY_YOUTUBE = "youtube_today"
    private const val KEY_PENDING_LIMIT = "pending_limit"
    private const val KEY_PENDING_AT = "pending_limit_at"

    private fun preferences(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun today(): String =
        SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    @Synchronized
    fun configure(
        context: Context,
        requestedLimit: Int,
        pendingLimit: Int,
        pendingAt: Long,
        instagram: Boolean,
        youtube: Boolean
    ) {
        val prefs = preferences(context)
        applyPendingLimitIfDue(prefs)
        val currentLimit = prefs.getInt(KEY_LIMIT, 0)
        val editor = prefs.edit()
            .putBoolean(KEY_INSTAGRAM_ENABLED, instagram)
            .putBoolean(KEY_YOUTUBE_ENABLED, youtube)

        if (requestedLimit > 0) {
            when {
                currentLimit <= 0 || requestedLimit <= currentLimit -> {
                    editor.putInt(KEY_LIMIT, requestedLimit)
                        .remove(KEY_PENDING_LIMIT)
                        .remove(KEY_PENDING_AT)
                }
                else -> {
                    val storedPendingLimit = prefs.getInt(KEY_PENDING_LIMIT, 0)
                    val storedPendingAt = prefs.getLong(KEY_PENDING_AT, 0L)
                    if (pendingLimit > currentLimit && pendingAt > 0L) {
                        editor.putInt(KEY_PENDING_LIMIT, pendingLimit)
                            .putLong(KEY_PENDING_AT, pendingAt)
                    } else if (storedPendingLimit != requestedLimit || storedPendingAt <= 0L) {
                        editor.putInt(KEY_PENDING_LIMIT, requestedLimit)
                            .putLong(
                                KEY_PENDING_AT,
                                System.currentTimeMillis() + 24 * 60 * 60 * 1000L
                            )
                    }
                }
            }
        }

        if (requestedLimit <= currentLimit && pendingLimit > currentLimit && pendingAt > 0L) {
            editor.putInt(KEY_PENDING_LIMIT, pendingLimit)
                .putLong(KEY_PENDING_AT, pendingAt)
        }

        editor.apply()
    }

    @Synchronized
    fun snapshot(context: Context): ProtectionSnapshot {
        val prefs = preferences(context)
        resetIfNeeded(prefs)
        applyPendingLimitIfDue(prefs)

        var total = 0
        var instagram = 0
        var youtube = 0
        val calendar = Calendar.getInstance()
        for (offset in 0..6) {
            calendar.time = Date()
            calendar.add(Calendar.DAY_OF_YEAR, -offset)
            val date = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(calendar.time)
            val dayInstagram = prefs.getInt("instagram_$date", 0)
            val dayYoutube = prefs.getInt("youtube_$date", 0)
            instagram += dayInstagram
            youtube += dayYoutube
            total += dayInstagram + dayYoutube
        }

        val instagramToday = prefs.getInt(KEY_INSTAGRAM, 0)
        val youtubeToday = prefs.getInt(KEY_YOUTUBE, 0)
        return ProtectionSnapshot(
            limit = prefs.getInt(KEY_LIMIT, 0),
            today = instagramToday + youtubeToday,
            instagramToday = instagramToday,
            youtubeToday = youtubeToday,
            weeklyTotal = total,
            instagramWeekly = instagram,
            youtubeWeekly = youtube
        )
    }

    @Synchronized
    fun increment(context: Context, instagram: Boolean): ProtectionSnapshot {
        val prefs = preferences(context)
        resetIfNeeded(prefs)
        applyPendingLimitIfDue(prefs)
        val key = if (instagram) KEY_INSTAGRAM else KEY_YOUTUBE
        val count = prefs.getInt(key, 0) + 1
        val date = today()
        prefs.edit()
            .putInt(key, count)
            .putInt("${if (instagram) "instagram" else "youtube"}_$date", count)
            .apply()
        return snapshot(context)
    }

    fun isEnabled(context: Context, instagram: Boolean): Boolean {
        val prefs = preferences(context)
        return prefs.getBoolean(
            if (instagram) KEY_INSTAGRAM_ENABLED else KEY_YOUTUBE_ENABLED,
            true
        )
    }

    private fun resetIfNeeded(prefs: android.content.SharedPreferences) {
        val date = today()
        if (prefs.getString(KEY_DATE, null) != date) {
            prefs.edit()
                .putString(KEY_DATE, date)
                .putInt(KEY_INSTAGRAM, 0)
                .putInt(KEY_YOUTUBE, 0)
                .apply()
        }
    }

    private fun applyPendingLimitIfDue(prefs: android.content.SharedPreferences) {
        val pendingLimit = prefs.getInt(KEY_PENDING_LIMIT, 0)
        val applyAt = prefs.getLong(KEY_PENDING_AT, 0L)
        if (pendingLimit > 0 && applyAt > 0L && System.currentTimeMillis() >= applyAt) {
            prefs.edit()
                .putInt(KEY_LIMIT, pendingLimit)
                .remove(KEY_PENDING_LIMIT)
                .remove(KEY_PENDING_AT)
                .apply()
        }
    }
}
