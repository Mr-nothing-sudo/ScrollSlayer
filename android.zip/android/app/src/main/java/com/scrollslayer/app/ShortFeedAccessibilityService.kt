package com.scrollslayer.app

import android.accessibilityservice.AccessibilityService
import android.graphics.Color
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class ShortFeedAccessibilityService : AccessibilityService() {
    private var windowManager: WindowManager? = null
    private var overlay: View? = null
    private var activePackage: String? = null
    private var activeFeed = false
    private var lastCountAt = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        val packageName = event.packageName?.toString() ?: return
        if (packageName == applicationContext.packageName) return

        val instagram = packageName == INSTAGRAM_PACKAGE
        val youtube = packageName == YOUTUBE_PACKAGE
        if (!instagram && !youtube) {
            activePackage = null
            activeFeed = false
            removeOverlay()
            return
        }

        if (!ProtectionStore.isEnabled(this, instagram)) {
            activePackage = packageName
            activeFeed = false
            removeOverlay()
            return
        }

        val isShortFeed = isShortFeed(rootInActiveWindow, instagram)
        if (!isShortFeed) {
            if (activePackage == packageName) {
                activeFeed = false
                removeOverlay()
            }
            activePackage = packageName
            return
        }

        activePackage = packageName
        val isNewFeed = !activeFeed
        activeFeed = true
        val isNewItem = event.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED &&
            event.eventTime - lastCountAt >= ITEM_DEBOUNCE_MS
        if (isNewFeed) {
            lastCountAt = event.eventTime
            showPrompt(
                ProtectionStore.snapshot(this),
                if (instagram) "Instagram Reels" else "YouTube Shorts"
            )
        } else if (isNewItem) {
            lastCountAt = event.eventTime
            val before = ProtectionStore.snapshot(this)
            val snapshot = if (before.limit > 0 && before.today >= before.limit) {
                before
            } else {
                ProtectionStore.increment(this, instagram)
            }
            showPrompt(snapshot, if (instagram) "Instagram Reels" else "YouTube Shorts")
        }
    }

    override fun onInterrupt() {
        removeOverlay()
    }

    override fun onDestroy() {
        removeOverlay()
        super.onDestroy()
    }

    private fun isShortFeed(root: AccessibilityNodeInfo?, instagram: Boolean): Boolean {
        root ?: return false
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var inspected = 0
        while (queue.isNotEmpty() && inspected++ < MAX_NODES) {
            val node = queue.removeFirst()
            val resourceId = node.viewIdResourceName?.lowercase().orEmpty()
            val idMatched = node.isVisibleToUser && if (instagram) {
                resourceId.contains("clips_viewer") || resourceId.contains("reels_viewer")
            } else {
                resourceId.contains("shorts_player") ||
                    resourceId.contains("shorts_container") ||
                    resourceId.contains("reel_watch_sequence")
            }
            if (idMatched) return true

            for (index in 0 until node.childCount) {
                node.getChild(index)?.let(queue::addLast)
            }
        }
        return false
    }

    private fun showPrompt(snapshot: ProtectionSnapshot, platform: String) {
        val limit = snapshot.limit
        if (limit <= 0) return
        val blocked = snapshot.today >= limit
        val title = if (blocked) "Daily limit reached" else "Pause before you scroll"
        val message = if (blocked) {
            "You watched ${snapshot.today} of $limit short videos today. $platform is blocked until your daily reset."
        } else {
            "You have watched ${snapshot.today} of your $limit daily short videos."
        }
        showOverlay(title, message, blocked)
    }

    private fun showOverlay(title: String, message: String, blocked: Boolean) {
        removeOverlay()

        val scrim = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(28), dp(28), dp(28), dp(28))
            setBackgroundColor(Color.argb(230, 14, 12, 20))
            isClickable = true
        }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(26), dp(24), dp(22))
            setBackgroundColor(Color.rgb(38, 35, 48))
        }
        val heading = TextView(this).apply {
            text = if (blocked) "⛔ $title" else "⚡ $title"
            textSize = 23f
            setTextColor(Color.rgb(196, 181, 253))
            gravity = Gravity.CENTER
        }
        val detail = TextView(this).apply {
            text = message
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, dp(18), 0, dp(18))
        }
        val action = Button(this).apply {
            text = if (blocked) "Leave the feed" else "Continue"
            setOnClickListener {
                if (blocked) {
                    performGlobalAction(GLOBAL_ACTION_BACK)
                    activeFeed = false
                }
                removeOverlay()
            }
        }
        card.addView(heading)
        card.addView(detail)
        card.addView(action)
        scrim.addView(
            card,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        )

        val layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        try {
            windowManager?.addView(scrim, layoutParams)
            overlay = scrim
        } catch (error: WindowManager.BadTokenException) {
            android.util.Log.e(TAG, "Could not show the short-feed overlay", error)
        }
    }

    private fun removeOverlay() {
        overlay?.let { view ->
            try {
                windowManager?.removeView(view)
            } catch (error: IllegalArgumentException) {
                android.util.Log.w(TAG, "Short-feed overlay was already removed", error)
            }
        }
        overlay = null
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    companion object {
        private const val TAG = "ScrollSlayerAccess"
        private const val INSTAGRAM_PACKAGE = "com.instagram.android"
        private const val YOUTUBE_PACKAGE = "com.google.android.youtube"
        private const val MAX_NODES = 800
        private const val ITEM_DEBOUNCE_MS = 900L
    }
}
